Project pythonanywhere URL:
https://caregetmeride.pythonanywhere.com/GetMeRide/default/index
admin password-qwerty

Instructions:

Normal User:
There are two tabs available for the non-admin user.
1. Share a cab:
	This would help user to share his cab.

2. Take a cab:
	This link would help user to book/search for a cab which is shared by some other user.

Admin user:
For admin, there is one more option available ("Add Route") which would help him to add new routes to the city routemap.

Login credentials:

1. Normal user:
	Username: kalra.udbhav@gmail.com
	Password: qwerty

2. Admin:
	Username: vipsyjain@yahoo.in
	Password: qwerty
